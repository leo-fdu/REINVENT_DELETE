MOE import: tab-separated, no header. Column 1 = SMILES; column 2 = molecule ID.
Preserve column 2 as the molecule name before QuickPrep/SDF export.
No chemistry changes, deduplication, 3D preparation or QuickPrep performed.
Each cohort file combines 30 target/mode inputs. ALL_6_COHORTS combines all six cohorts.
Import either individual cohorts OR the ALL file, not both.
Original TXT line order within each target/mode is preserved. IDs match existing source SMI/manifest records.

reinvent-20260927_first1000_complete.txt: 29380 molecules
reinvent-high8-1000-20261025_complete.txt: 29637 molecules
reinvent-high9-1000-20261025_complete.txt: 29608 molecules
reinvent-high9-cap9-size001-1000-20261025_complete.txt: 29722 molecules
reinvent-high9-cap9-size0015-1000-20261025_complete.txt: 29753 molecules
reinvent-high9-cap9-size002-1000-20261025_complete.txt: 29768 molecules
Total: 177868 molecules
